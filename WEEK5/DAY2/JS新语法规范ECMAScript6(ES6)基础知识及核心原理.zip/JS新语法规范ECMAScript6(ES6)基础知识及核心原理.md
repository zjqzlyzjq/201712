##JS新语法规范ECMAScript6(ES6)基础知识及核心原理
@(201712)

###使用Babel编译ES6
> 一、下载安装Babel
> 环境：需要电脑上安装node（node中一般都会自带npm包管理器）
> 
>  `npm install babel-cli -g` 把模块安装在全局环境下（在任何的项目中，都可以使用命令来编译我们的代码了）
> `npm uninstall babel-cli -g` 把全局下安装的babel模块卸载掉

![Alt text](./1511324975060.png)

> 观看安装目录发现一些细节需要了解的知识点：
> 1、我们后期之所以可以使用babel的命令，是因为安装在全局环境下之后，会生成一些 xxx.cmd 的文件，而这里的xxx就是可以在DOC窗口中执行的命令
> `babel.cmd` 以后可以使用babel命令了
> `babel-node.cmd` 
> ...
>  
> 2、执行babel命令后我们可以完成一些编译或者其它的任务，主要原因是执行babel命令后，会自动加载一些处理任务的文件
![Alt text](./1511325859051.png)

> 二、配置.babelrc文件，安装一些语言解析包
> 1、我们需要把.babelrc文件配置在当前项目的根目录下（这个文件没有文件名，后缀名是babelrc）
> a：在电脑上不能直接创建没有文件名的文件，我们需要使用WS中的 new -> file 来创建，或者使用命令创建
> b：babelrc这个后缀名在某些ws中是不识别的，它其实是一个json文件，我们需要在ws中配置一下（让他隶属于json文件）
![Alt text](./1511326610899.png)

> 2、在文件中编写一些内容
```json
{
  "presets": [], //=>存放的是，我们编译代码时候需要依赖的语言解析包
  "plugins": [] //=>存放的是，我们编译代码时候需要依赖的插件信息
}
```

> 3、安装依赖的语言解析包
> 在当前项目的根目录下安装（不是安装在全局），需要特殊注意的是：要在当前项目根目录中打开DOC命令才可以
> `npm install babel-preset-latest` 安装最新已经发布的语言标准解析模块
> `npm install babel-preset-stage-2` 安装当前还没有发布但是已经进入草案的语言解析模块（如果你的代码中用到了发布非标准的语法，我们需要安装他）
> ...
> 安装成功后在自己的当前项目根目录下，会存在一个 `node_modules`文件夹，在这个文件夹中有我们安装的模块
> 
> 4、完成最后.babelrc文件的配置
```json
{
  "presets": [
    "latest",
    "stage-2"
  ],
  "plugins": []
}
```

> 三、使用命令编译JS代码
> 基本上所有支持命令操作的模块都有一个命令
> `babel --help / babel -h` 查看帮助
>  
> `babel --version / babel -V` 查看版本号
>  
> `babel --out-file / babel -o` 把某一个JS文件中的ES6代码进行编译
>  
> `babel --out-dir / babel -d` 把某一个文件夹中所有的JS文件中的ES6代码进行编译
>  
> `babel --watch / babel -w` 监听文件中代码的改变，当代码改变后，会自动进行编译
> 
> 结束监听的程序：`ctrl+c 按两遍`

![Alt text](./1511336291587.png)

###ES6中的let和const
`let基础语法`
> `let 变量名 = 变量值`
>  
> 使用let创建变量和使用var创建变量的区别
> 
> 1、let不存在变量提升机制
```javascript
console.log(str);//=>undefined
console.log(fn);//=>FN本身
console.log(avg);//=>undefined
console.log(sum);//=>Uncaught ReferenceError: sum is not defined
console.log(num);//=>Uncaught ReferenceError: num is not defined

var str = '珠峰培训';
let num = 12;
function fn() {}
var avg = function () {};
let sum = function () {};

//=>ES6中只提供了创建变量的新语法标准（let），创建函数还是沿用ES5中的function（还会存在变量提升），如果想让函数也不存在变量提升，都使用函数表达式赋值的方式操作：let fn=function(){}

//=>创建变量
let xxx=xxx;

//=>创建函数
let xxx=function(){}

//=>自执行函数
;(function(){
	
})();

//=>好处：此时代码中就不要在考虑变量提升了，只要这样处理，没有所谓的变量提升
```

> 2、使用let定义的变量不允许在`同一个作用域中`重复声明
```javascript
var num2 = 12;
var num2 = 13;
console.log(num2);//=>13

let str = '珠峰';
let str = '培训';
console.log(str);//=>Uncaught SyntaxError: Identifier 'str' has already been declared  当前报错,上面代码也不会执行(在JS代码执行之前就已经知道有重复声明的了，也就是浏览器依然存在类似于变量提升的机制：在JS代码之前先把所有LET声明的变量过一遍，发现有重复的直接报错)

let num = 12;
num = 13;
console.log(num);//=>13 LET不允许重复被声明，但是允许重新赋值

var att=200;
let att=100;//=>Uncaught SyntaxError: Identifier 'att' has already been declared 不管你之前使用什么方式在当前作用域中声明的变量，再使用let声明的时候都会报错
```

```javascript
let num = 12,
    fn = function () {
        let num = 13;
    };
console.log(num);//=>12 当前作用域下别重复声明即可(不同作用域中的变量是自己私有的,名字重复没有关系)

let att = 13,
    sum = function () {
        att = 14;
    };
sum();
console.log(att);//=>let也存在私有变量和作用域链的概念，和ES5中基本上差不多  =>14
```

> 3、关于暂时性死区：使用typeof检测一个未被声明过的变量
> ES5中返回的结果是undefined但是不报错
> ES6中直接报错
```javascript
"use strict";
console.log(typeof num);//=>undefined 当前变量不存在,但是使用typeof检测的时候,不会提示错误,而是返回undefined

console.log(typeof num);//=>Uncaught ReferenceError: num is not defined  ES6中检测一个没有被声明过的变量直接报错,不像之前ES5中的值是UNDEFINED一样了
let num;

let num;
console.log(typeof num);//=>undefined 只声明没有定义(赋值),默认值是UNDEFINED
```

> 4、ES6语法创建的变量(let)存在块级作用域，ES5语法创建变量(var/function)没有块级作用域
>  
> [ES5]
> window全局作用域
> 函数执行形成的私有作用域
>  
> [ES6]
> 除了有ES5中的两个作用域，ES6中新增加块级作用域（我们可以把块级作用域理解为之前学习的私有作用域：存在私有变量和作用域链的一些机制） `ES6语法中把大部分用大括号包起来都称之为块级作用域`

```javascript
let num = 12,
    str = '';
let fn = function (str) {
    str = 'HELLO';
    //console.log(arguments[0]);//=>"HELLO" 当前JS并没有开启严格模式,所以形参变量和ARG存在映射机制(但是我们以后尽量不要这样处理:因为把ES6编译为ES5之后,会默认的开启严格模式,映射机制会中断,此处的值依然是'珠峰',这样导致我们的ES6结果和ES5结果不一致)
    // console.log(num);//=>Uncaught ReferenceError: num is not defined
    let num = 13;
    console.log(num, str);//=>13 "HELLO"
};
fn('珠峰');
console.log(num, str);//=>12 ''
```
> 大部分我们遇到的大括号操作都是块级作用域
```javascript
/*
if (10 >= 10) {
    let total = 100;
}
console.log(total);//=>Uncaught ReferenceError: total is not defined 判断体也是一个块级私有作用域,在这个作用域中声明的变量是私有变量,在块级作用域之外是无法使用的
*/

/*
for (let i = 0; i < 5; i++) {
    console.log(i);
}
console.log(i);//=>Uncaught ReferenceError: i is not defined 循环体也是一个块级作用域（每一次循环都会形成一个新的块级作用域：当前案例形成五个块级作用域，每一个块级作用域中都有一个私有变量i，分别存储的是0~4）
*/

/*{
    let i=12;
}
console.log(i);//=>Uncaught ReferenceError: i is not defined 这是一个ES6中标准的块级作用域*/

/*
let i=10;
{
    let i=20;
    {
        {
            console.log(i);//=>Uncaught ReferenceError: i is not defined 虽然ES6没有变量提升，但是每一次进入当前作用域都会把LET定义的变量找一遍（不提升但是找了，找到了说明当前作用域中是有这个变量的，提前用都会报错）
        }
        let i=30;
    }
}
*/

/*
try{
    let i=100;
}catch (e){
    let k=200;
}
console.log(k);//=>Uncaught ReferenceError: k is not defined
console.log(i);//=>Uncaught ReferenceError: i is not defined TRY CATCH中的任何大括号都是块级作用域
*/

/*
switch (10){
    case 10:
        let i=20;
        break;
}
console.log(i);//=>Uncaught ReferenceError: i is not defined
*/

/*
let obj={name:'珠峰'};
for (let key in obj) {

}
console.log(key);//=>Uncaught ReferenceError: key is not defined
*/
```
> 块级作用域的增加有什么用？
```javascript
let tempList = document.getElementsByName('TEMP');
// for (var i = 0; i < tempList.length; i++) {
//     tempList[i].onclick = function () {
//         console.log(i);//=>5 怎么点击都是5 异步操作以及作用域链的查找,找到的都是全局下最后一次循环的结束值
//     }
// }

//=>自定义属性解决
// for (var i = 0; i < tempList.length; i++) {
//     tempList[i].index = i;
//     tempList[i].onclick = function () {
//         console.log(this.index);
//     }
// }

//=>闭包解决
// for (var i = 0; i < tempList.length; i++) {
//     ~function (i) {
//         tempList[i].onclick = function () {
//             console.log(i);
//         }
//     }(i);
// }

//=>使用ES6的块级作用域
for (let i = 0; i < tempList.length; i++) {
    tempList[i].onclick = function () {
        console.log(i);
    }
}
```

`const的基础语法`
> const的细节知识点和let一样，和let的主要区别在于：let是创建变量，const是创建常量
>  
> 变量：值是可以修改的
> 常量：值不能被修改

```javascript
let num = 12;
num = 13;
console.log(num);//=>13

const str = '珠峰';
str = '培训';//=>而且使用BABEL如果遇到了CONST设置的常量在进行修改，就无法进行编译了
console.log(str);//=>Uncaught TypeError: Assignment to constant variable.
```

`JS中创建变量方式汇总`
> `var` ：ES5中创建变量
> `function`：ES5中创建函数
> ES5中创建变量或者函数存在：变量提升、重复声明等特征，但是没有块级作用域的机制
>  
> `let`：ES6中创建变量
> `const`：ES6创建常量
> ES6中创建的变量或者常量都不可以变量提升，也不可以重复声明，而且还存在块级作用域
>  
> `class`：ES6中创建类的方式
> `import`：ES6中模块导入的方式
```javascript
class Parent{
	constructor(){
		//=>this.xxx=xxx
	}
	//=>Parent.prototype
	aa(){}
	
	//=>Parent own property
	static bb(){}
}
```