###Math中常用的方法

@(201712)

> 数学函数：它属于对象数据类型  `typeof Math ->'object'`
> 
> Math对象中提供了很多操作数字的方法
> `console.dir(Math)`
![Alt text](./1508304685714.png)
![Alt text](./1508304710273.png)

`abs`
> Math.abs：取绝对值
```javascript
Math.abs(12) ->12
Math.abs(-12) ->12
```

`ceil && floor`
> Math.ceil：向上取整
> Math.floor：向下取整
```javascript
Math.ceil(12) ->12
Math.ceil(12.1) ->13
Math.ceil(12.9) ->13
Math.ceil(-12.1) ->-12
Math.ceil(-12.9) ->-12

Math.floor(12) ->12
Math.floor(12.1) ->12
Math.floor(12.9) ->12
Math.floor(-12.1) ->-13
Math.floor(-12.9) ->-13
```

`round`
> Math.round：四舍五入
```javascript
Math.round(12.3) ->12
Math.round(12.5) ->13 正数中5包含在向上

Math.round(-12.3) ->-12
Math.round(-12.5) ->-12 负数中5包含在向下
Math.round(-12.51) ->-13
```

`random`
> Math.random：获取(0,1)之间的随机小数
```javascript
for(var i=0;i<100;i++){
	console.log(Math.random());
}

//=>需求：获取[0,10]之间的随机整数
Math.round(Math.random()*10)

//=>需求：获取[3,15]之间的随机整数
Math.round(Math.random()*12+3)
```
> 获取[n,m]之间的随机整数
> `Math.round(Math.random()*(m-n)+n)`

`max && min`
> Math.max：获取一组值中的最大值
> Math.min：获取一组值中的最小值
```javascript
Math.max(12,23,14,24,34,25,13,15,16,27,13,12); ->34
Math.min(12,23,14,24,34,25,13,15,16,27,13,12); ->12
```

`PI`
> Math.PI：获取圆周率（π）
```javascript
Math.PI ->3.141592653589793
```

`pow && sqrt`
> Math.pow：获取一个值的多少次幂
> Math.sqrt：开平方
```javascript
Math.pow(10,2) ->100
Math.sqrt(100) ->10
```
