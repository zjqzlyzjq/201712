<?php
   echo "Hello Ajax!";
?>